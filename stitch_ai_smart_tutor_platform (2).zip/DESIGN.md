---
name: Kinetic Horizon
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#684000'
  on-tertiary: '#ffffff'
  tertiary-container: '#885500'
  on-tertiary-container: '#ffd4a4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system is tailored for K-12 learners across diverse curricula, delivering an environment that balances academic rigor with intrinsic motivation. The personality is energetic, encouraging, structured, and clear. It counteracts cognitive overload by eliminating clutter while celebrating student progress through tactile feedback, vibrant milestone markers, and inviting spatial clarity.

The visual style blends **Modern Soft Clean** with subtle **Frosted Layering (Glassmorphism)** and tactile micro-affordances:
- **Calm, High-Clarity Canvas:** Light, luminous backgrounds that reduce eye fatigue during long revision sessions.
- **Dopamine-Positive Accents:** High-chroma gamification cues (streaks, mastery rings, XP indicators) reserved strictly for pedagogical achievements and feedback states.
- **Friendly Precision:** Generous touch footprints, soft structural curves, and clear content chunking that cater equally to primary school tablet users and high-schoolers on desktop or mobile.
- **Pedagogical Hierarchy:** Distinct visual buckets separating reference material, interactive query zones, and feedback loops.

## Colors

The palette establishes an energetic visual rhythm anchored in high-legibility contrast.

### Role Assignments
- **Primary (`#4F46E5` Electric Indigo):** The core active brand driver. Used for global actions, primary navigation nodes, key progress anchors, active tab indicators, and focal interactive states.
- **Secondary (`#7C3AED` Deep Violet):** Contextual depth and AI-assisted workflows. Powers interactive AI tutoring prompts, adaptive question cards, hints, and secondary category badges.
- **Tertiary / Gamification Accent (`#F59E0B` Amber Spark):** Dedicated strictly to rewards, daily streaks, XP counters, leaderboards, and star ratings. Never used for general informational text.
- **Success / Mastery (`#10B981` Emerald Green):** Denotes correct answers, syllabus mastery, completed modules, and positive performance deltas.
- **Correction / Error (`#EF4444` Coral Rose):** Applied to incorrect attempts, error states, and revision tags. Paired with soft tint backdrops (`#FEF2F2`) to remain instructive rather than punitive.
- **Neutral Core (`#0F172A` Deep Slate):** Primary typographic ink. Delivers sharp legibility without the harshness of pure black.
- **Neutral Surfaces (`#F8FAFC` to `#FFFFFF`):** Multi-tier surface foundation. `#F8FAFC` forms the broad canvas; `#FFFFFF` isolates individual task cards, modules, and modals.

## Typography

Plus Jakarta Sans serves as the single typographic voice across display, body, and label roles. Its geometric roundness offers warmth and accessibility to younger learners, while its tall x-height and sharp terminals ensure high legibility for dense technical topics, formulas, and multi-paragraph problem statements.

### Editorial Guidelines
- **Headlines & Problem Prompts:** Set in `headline-lg` or `headline-md` using medium-heavy weights (`600` or `700`) to anchor the student’s focus before entering an exercise.
- **Reading Comfort:** Academic explanations and solution walk-throughs default to `body-lg` or `body-md` with relaxed line-height ratios (`1.5` to `1.55`) to facilitate scanning without eye strain.
- **Micro-Copy & Badges:** Gamification tags, board affiliations (CBSE, ICSE), and chapter difficulty markers use uppercase tracking with `label-sm` or `label-md` to remain distinct from educational prose.

## Layout & Spacing

The layout employs a responsive, fluid grid system anchored by an 8pt spatial cadence. Spacing separates distinct learning modules cleanly, avoiding claustrophobic data packing.

### Grid & Breakpoints
- **Mobile (< 768px):** 4-column layout with `margin-mobile` (1rem) and `gutter-mobile` (1rem). Touch targets scale to a mandatory minimum dimension of 48px by 48px to support rapid mobile thumb navigation.
- **Tablet (768px - 1024px):** 8-column layout with 1.5rem gutters and margins. Splits split-screen reading panes (passage on left, interactive quiz items on right).
- **Desktop (> 1024px):** 12-column layout with a maximum container limit of `1280px`, flanked by `margin` (2rem) and `gutter` (1.5rem).

### Layout Rules
- **Chunked Pedagogy:** Study sessions should not scroll continuously. Group content into discrete cards with vertical element gaps driven by `space-md` internally and `space-xl` between sections.
- **Safe-Action Zones:** Bottom sheet actions and practice submit controls are pinned above mobile navigational bars with a minimum buffer of `space-md`.

## Elevation & Depth

Visual depth is achieved through **ambient tinting, layered cards, and subtle glass headers**, ensuring floating elements feel weightless rather than heavy.

### Elevation Hierarchy
- **Level 0 (Canvas Base):** Flat `#F8FAFC`. The foundational backdrop for the entire workspace.
- **Level 1 (Card Default):** `#FFFFFF` surfaces with a 1px border (`#E2E8F0`) and an ambient, Indigo-tinted shadow: `0 1px 3px rgba(15, 23, 42, 0.04), 0 4px 12px rgba(79, 70, 229, 0.03)`. Used for study cards, test questions, and dashboard units.
- **Level 2 (Interactive Hover / Selected Card):** Raised surface with an amplified soft shadow: `0 8px 24px rgba(79, 70, 229, 0.08)` and border highlighted in 1.5px Primary Indigo (`#4F46E5`).
- **Level 3 (Sticky Headers & Overlays):** Frosted glass effect with `background: rgba(255, 255, 255, 0.82)`, backdrop filter `blur(12px)`, and a crisp lower hairline border of `rgba(226, 232, 240, 0.8)`. Used for top progress headers, persistent test timers, and dynamic XP heads-up displays.
- **Level 4 (Modals & Celebration Overlays):** Deep layered floating sheet with `0 20px 40px rgba(15, 23, 42, 0.12)` positioned over an ambient scrim (`rgba(15, 23, 42, 0.4)` with 4px backdrop blur).

## Shapes

The shape system adopts a friendly, modern contour. Rounded geometry is friendly and safe for younger age groups while retaining a clean profile suitable for high school learners.

### Corner Radius System
- **Compact Elements (Tags, Badges, Inputs):** 8px (`0.5rem`). Provides defined form boundaries without harsh edges.
- **Interactive Surfaces & Buttons:** 12px to 16px (`rounded-lg` to `rounded-xl`). Ergonomically soft for touch interactions.
- **Core Cards & Module Containers:** 24px (`rounded-2xl`). Softens large surface breaks across both tablet and desktop views.
- **Gamified Elements & Pill Overlays:** Full radius (`rounded-full` / 9999px) for streak chips, XP pills, avatar frames, and floating category switchers.

## Components

### Buttons
- **Primary Button:** `#4F46E5` background, `#FFFFFF` text, `rounded-xl` (16px), minimum height 48px. Features a micro-interaction state that drops 1px on click with an active shadow shift (`0 2px 4px rgba(79, 70, 229, 0.2)`).
- **Secondary / Ghost Action:** `#EEF2FF` light indigo fill with `#4F46E5` label. No border. Used for hints, scratchpad triggers, and secondary navigation.
- **Streak / XP Special Action:** Gradients transitioning from `#F59E0B` to `#D97706` with white text and gold glow shadow (`0 4px 12px rgba(245, 158, 11, 0.3)`).

### Cards (Question & Module)
- Base background `#FFFFFF` bordered by `#E2E8F0` with `rounded-2xl` corners and `space-lg` internal padding.
- **Option Selection Card:** Unselected state sits at Level 1 elevation with slate text. Selected state shifts to `#EEF2FF` fill with a solid 2px `#4F46E5` border and glowing indicator checkmark.
- **Solution/Explanation Card:** Distinct `#F8FAFC` background with an emerald green left border accent (4px) when correct, or rose left border accent when reviewing a mistake.

### Badges & Chips
- **Curriculum Chips (CBSE / ICSE / Board):** Pill-shaped (`rounded-full`), `#F1F5F9` background, `#475569` text, `label-sm` bold uppercase typography.
- **Gamification Badges (Streak / XP):** `#FEF3C7` background, `#B45309` text, paired with dynamic iconography (flame or star).
- **AI Assist Badge:** `#F5F3FF` background with `#7C3AED` text and subtle sparkle icon.

### Form Inputs & Fields
- Height 48px, `rounded-xl`, `#FFFFFF` surface with `#CBD5E1` border.
- **Focus State:** 2px focus ring using `#4F46E5` with an ambient glow (`box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.15)`).
- Floating label or crisp top label using `label-md` in `#475569`.

### Checkboxes & Radios
- Size 22px by 22px for enhanced touch targets on tablet and mobile.
- Unchecked: `#FFFFFF` fill with 2px `#CBD5E1` border.
- Checked: `#4F46E5` fill with smooth white check or dot icon transition (`scale-100` spring animation).

### Specialized EdTech Components
- **Curriculum Mastery Ring:** SVG progress circles with `#E2E8F0` track and `#10B981` stroke representing chapter completion percentage.
- **Dynamic AI Hint Drawer:** Frosted bottom-sheet or side-pane featuring a violet hairline border (`#7C3AED`) and stepped accordion reveals to encourage self-directed deduction before showing answers.